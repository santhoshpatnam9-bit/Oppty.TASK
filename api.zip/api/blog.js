// Wait for the page to load before starting
document.addEventListener('DOMContentLoaded', function() {
    // Get all the HTML elements we need to work with
    const postsContainer = document.getElementById('posts-container');
    const selectedPost = document.getElementById('selected-post');
    const loadingIndicator = document.getElementById('loading-indicator');
    const errorMessage = document.getElementById('error-message');
    const refreshBtn = document.getElementById('refresh-posts-btn');
    const loadMoreBtn = document.getElementById('load-more-btn');
    
    // Keep track of our blog posts and current page
    let allPosts = [];
    let currentPage = 1;
    let isLoading = false;
    
    // Start by loading the first page of blog posts
    loadBlogPosts();
    
    // Set up buttons to work when clicked
    refreshBtn.addEventListener('click', refreshBlogPosts);
    loadMoreBtn.addEventListener('click', loadMoreBlogPosts);
    
    // Function to load blog posts from the API
    async function loadBlogPosts(page = 1) {
        // Don't load if we're already loading
        if (isLoading) return;
        
        // Show loading message to user
        isLoading = true;
        showLoadingMessage();
        
        try {
            // Get blog posts from the API (8 posts per page)
            const response = await fetch(`https://jsonplaceholder.typicode.com/posts?_page=${page}&_limit=8`);
            
            // Check if the request worked
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            // Get the posts from the response
            const newPosts = await response.json();
            
            // Add extra information to each post (date and random image)
            const randomImages = [
                'https://picsum.photos/300/200?random=1',
                'https://picsum.photos/300/200?random=2',
                'https://picsum.photos/300/200?random=3',
                'https://picsum.photos/300/200?random=4',
                'https://picsum.photos/300/200?random=5',
                'https://picsum.photos/300/200?random=6',
                'https://picsum.photos/300/200?random=7',
                'https://picsum.photos/300/200?random=8'
            ];
            
            // Add date and random image to each post
            const postsWithExtraInfo = newPosts.map((post, index) => {
                const randomIndex = Math.floor(Math.random() * randomImages.length);
                return {
                    ...post,  // Keep all original post data
                    date: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toLocaleDateString(), // Random date
                    imageUrl: randomImages[randomIndex] // Random image for each post
                };
            });
            
            // If loading first page, replace all posts
            // If loading more, add to existing posts
            if (page === 1) {
                allPosts = postsWithExtraInfo;
            } else {
                allPosts = [...allPosts, ...postsWithExtraInfo];
            }
            
            // Show all posts on the page
            displayPosts();
            
            // Hide loading message and any error messages
            hideLoadingMessage();
            hideErrorMessage();
        } catch (error) {
            // Show error if something goes wrong
            console.error('Error getting blog posts:', error);
            showErrorMessage('Could not load blog posts. Please try again.');
            hideLoadingMessage();
        } finally {
            // Always stop loading when done
            isLoading = false;
        }
    }
    
    // Function to show blog posts on the page
    function displayPosts() {
        // Clear current posts
        postsContainer.innerHTML = '';
        
        // Show each post
        allPosts.forEach(post => {
            // Create a new element for this post
            const postElement = document.createElement('article');
            postElement.className = 'blog-post';
            postElement.setAttribute('aria-label', `Blog post: ${post.title}`);
            
            // Add HTML content for this post
            postElement.innerHTML = `
                <img src="${post.imageUrl}" alt="${post.title}" class="post-image" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                <div class="image-placeholder" style="display: none; align-items: center; justify-content: center; color: white; font-size: 2.5rem; font-weight: bold;">
                    ${post.title.charAt(0).toUpperCase()}
                </div>
                <div class="post-body">
                    <h3 class="post-title">${post.title}</h3>
                    <p class="post-excerpt">${shortenText(post.body, 100)}</p>
                    <div class="post-meta">
                        <span>By User ${post.userId}</span>
                        <time datetime="${post.date}">${post.date}</time>
                    </div>
                </div>
            `;
            
            // When user clicks post, show details
            postElement.addEventListener('click', () => showPostDetails(post));
            
            // Add post to the page
            postsContainer.appendChild(postElement);
        });
    }
    
    // Function to show details of a selected post
    function showPostDetails(post) {
        // Update the detail section with post information
        selectedPost.innerHTML = `
            <img src="${post.imageUrl}" alt="${post.title}" class="detail-image" onerror="this.style.display='none';">
            <h4 class="detail-title">${post.title}</h4>
            <div class="post-info">
                <span class="author">Author: User ${post.userId}</span>
                <time class="post-date" datetime="${post.date}">${post.date}</time>
            </div>
            <div class="post-content">
                <p>${post.body}</p>
            </div>
        `;
    }
    
    // Function to shorten long text
    function shortenText(text, maxLength) {
        // If text is short enough, return as is
        if (text.length <= maxLength) return text;
        
        // Otherwise cut off and add ...
        return text.substr(0, maxLength) + '...';
    }
    
    // Functions to show/hide loading message
    function showLoadingMessage() {
        loadingIndicator.style.display = 'block';
    }
    
    function hideLoadingMessage() {
        loadingIndicator.style.display = 'none';
    }
    
    // Functions to show/hide error messages
    function showErrorMessage(message) {
        errorMessage.textContent = message;
        errorMessage.style.display = 'block';
    }
    
    function hideErrorMessage() {
        errorMessage.style.display = 'none';
    }
    
    // Function to refresh blog posts (load first page again)
    function refreshBlogPosts() {
        currentPage = 1;
        loadBlogPosts(currentPage);
    }
    
    // Function to load more blog posts (next page)
    function loadMoreBlogPosts() {
        // Don't load if we're already loading
        if (isLoading) return;
        
        // Go to next page and load
        currentPage++;
        loadBlogPosts(currentPage);
    }
});