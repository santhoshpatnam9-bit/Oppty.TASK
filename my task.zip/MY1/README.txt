Bridge Restaurant - Complete Offline Website
============================================

This is a complete offline copy of the Bridge Restaurant demo website, created using HTTrack Website Copier.

FILE STRUCTURE:
--------------

MY/
├── index.html                    # Main entry point - improved for human readability
├── offline_guide.html           # Comprehensive offline usage guide
├── README.txt                  # This file
├── backblue.gif               # Background image
├── fade.gif                   # Background image
├── cookies.txt                # Cookie data from original site
├── hts-log.txt               # HTTrack download log
├── demo.qodeinteractive.com/  # Main website directory
│   └── bridge85/             # Bridge Restaurant website files
│       ├── index.html        # Main website homepage
│       ├── chef/            # Chef section pages
│       ├── dishes/          # Dishes section pages
│       ├── menu/            # Menu section pages
│       ├── story/           # Story section pages
│       ├── reserve/         # Reservation section pages
│       ├── wp-content/      # WordPress content (themes, plugins, uploads)
│       ├── wp-includes/     # WordPress core includes
│       └── ...              # Other website files
├── hts-cache/                # HTTrack cache files
├── toolbar.qodeinteractive.com/ # Toolbar assets
└── twitter.com/              # Twitter share files

HOW TO USE:
-----------

1. Open "index.html" in your web browser to access the main entry page
2. Use the navigation links to browse different sections of the website
3. All content is stored locally - no internet connection required
4. All images, CSS, JavaScript, and other resources are included

KEY FEATURES:
-------------

- Complete offline functionality
- All images and media files included
- Full navigation between pages
- All CSS and JavaScript preserved
- Responsive design maintained
- All forms and interactive elements preserved (where possible)

TROUBLESHOOTING:
----------------

- If images don't load, make sure you're opening the files in a web browser
- Some external links may not work (they require internet connection)
- JavaScript functionality is preserved for offline use
- All pages load quickly since they're stored locally

ABOUT:
------

This offline copy preserves the complete functionality of the original Bridge Restaurant demo website, allowing you to explore and use it without any internet connection. The website was originally built with WordPress and includes various plugins and customizations.